public abstract class Personnage {
    //Nom, pv et objet de ArmeBase qui permet l'inheritance
    protected String nom;
    protected int hp;
    protected ArmeBase arme;

    //Constructeur Personnage
    public Personnage(String nom, int hp)
    {
        this.nom = nom;
        this.hp = hp;
    }

    //Setter et getter pour nom
    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public String getNom()
    {
        return this.nom;
    }

    //Setter et getter pour point de vie
    public void setHp(int hp)
    {
        this.hp = hp;
    }

    public int getHp()
    {
        return this.hp;
    }

    //récuperer l'arme
    public ArmeBase getArme() {
        return arme;
    }

    //inutile pour le moment
    @SuppressWarnings("unused")
    public abstract void attaquer(Personnage personnage);
}