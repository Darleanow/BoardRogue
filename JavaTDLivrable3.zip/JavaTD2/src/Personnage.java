import java.util.Scanner;

public abstract class Personnage {
    public void promptCharacterInfo()
    {

        System.out.println("Entrez les informations pour votre " + getClass().getSimpleName());

        setName();
        setPv();
        setAttack();
        setWeapon();
        setDefense();
    }

    public void setName()
    {
        System.out.println("Entrez son nom: ");
        this.name = scan.nextLine();
    }

    public String getName()
    {
        return this.name;
    }

    public void setPv()
    {
        System.out.println("Entrez ses points de vie (Min: " + getMinHP()
                + ",Max: " + getMaxHP() + ": ");
        this.hp = Integer.parseInt(scan.nextLine());

        while (this.hp < getMinHP() || this.hp > getMaxHP()) {
            System.out.println("Valeur invalide! Entrez une valeur entre "
                    + getMinHP() + " et " + getMaxHP());
            System.out.println("Entrez ses points de vie (Min: " + getMinHP()
                    + ",Max: " + getMaxHP() + "): ");
            this.hp = Integer.parseInt(scan.nextLine());
        }
    }

    public int getPv()
    {
        return this.hp;
    }

    public void setAttack()
    {
        System.out.println("Entrez ses points d'attaque (Min: " + getMinAttack()
                + ", Max: "+ getMaxAttack() + ": ");
        this.attack = Integer.parseInt(scan.nextLine());

        while (this.attack < getMinAttack() || this.attack > getMaxAttack()) {
            System.out.println("Valeur invalide! Entrez une valeur entre "
                    + getMinAttack() + " et " + getMaxAttack());
            System.out.println("Entrez ses points d'attaque (Min: " + getMinAttack()
                    + ",Max: " + getMaxAttack() + "): ");
            this.attack = Integer.parseInt(scan.nextLine());
        }
    }

    public int getAttack()
    {
        return this.attack;
    }

    public void setWeapon()
    {
        System.out.println(getWeaponPrompt());
        this.weapon = scan.nextLine();
    }

    public String getWeapon()
    {
        return this.weapon;
    }

    public void setDefense()
    {
        System.out.println(getDefensePrompt());
        this.defense = scan.nextLine();
    }

    public String getDefense()
    {
        return this.defense;
    }

    public void showOptions()
    {
        int choice = 0;
        while (choice != 3)
        {
            System.out.println("Que voulez vous faire ?");
            System.out.println("1. Voir votre héro");
            System.out.println("2. Modifier votre héro");
            System.out.println("3. Quitter");
            choice = Integer.parseInt(scan.nextLine());

            if (choice == 1)
            {
                displayHero();
            } else if (choice == 2)
            {
                int secondChoice = 1;
                System.out.println("Que voulez vous modifier ?");
                System.out.println("1. Nom de votre héro");
                System.out.println("2. Attaque de votre héro");
                System.out.println("3. Points de vie de votre héro");
                System.out.println("4. Arme de votre héro");
                System.out.println("5. Arme défensive votre héro");
                secondChoice = Integer.parseInt(scan.nextLine());
                changeHero(secondChoice);
            }
        }

    }

    public void changeHero(int index)
    {
        switch (index)
        {
            case 1:
                setName();
                break;
            case 2:
                setAttack();
                break;
            case 3:
                setPv();
                break;
            case 4:
                setWeapon();
                break;
            case 5:
                setDefense();
                break;
        }
    }
    public void displayHero()
    {
        System.out.println("Nom du joueur: " + getName());
        System.out.println("Attaque du joueur: " + getAttack());
        System.out.println("Points de vie du joueur: " + getPv());
        System.out.println("Arme du joueur: " + getWeapon());
        System.out.println("Arme de défense du joueur: " + getDefense());
    }

    //Methodes abstraites pour les seuil d'hp/vie
    public abstract int getMinHP();
    public abstract int getMaxHP();
    public abstract int getMinAttack();
    public abstract int getMaxAttack();

    public abstract String getWeaponPrompt();
    public abstract String getDefensePrompt();

    private Scanner scan = new Scanner(System.in);

    //Attributs basiques
    protected int hp, attack;
    protected String name, weapon, defense;
}

