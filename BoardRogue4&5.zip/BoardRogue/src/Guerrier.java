public class Guerrier extends Personnage {
    //Final pour l'économie de mémoire
    private final Arme arme;

    //Constructeur guerrier, super
    public Guerrier(String nom, int hp, Arme arme)
    {
        //On construit le nom/hp du parent pour économiser la mémoire
        super(nom, hp);
        this.arme = arme;
    }

    //Récuperer les infos de classe
    @Override
    public String toString() {
        return "Nom: " + getNom() + ", Classe: " + getClass().getSimpleName() + ", HP: " + getHp();
    }

    //Setter  et getter hp, on utilise super pour la mémoire
    @Override
    public void setHp(int hp) {
        super.setHp(hp);
    }

    @Override
    public int getHp() {
        return super.getHp();
    }

    //Setter et getter nom
    @Override
    public void setNom(String nom) {
        super.setNom(nom);
    }

    @Override
    public String getNom() {
        return super.getNom();
    }

    //setter et getter arme
    @Override
    public ArmeBase getArme() {
        return arme;
    }

    //attaquer un personnage
    @Override
    public void attaquer(Personnage personnage)
    {
        arme.cast();
        //ajouter si besoin...
    }
}