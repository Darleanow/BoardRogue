import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("Bienvenue, Entrez 1 pour guerrier ou 2 pour mage: ");

        int choice = Integer.parseInt(scan.nextLine());

        Personnage perso = null;

        if (choice == 1)
        {
            perso = new Guerrier();
            perso.promptCharacterInfo();
        } else if (choice == 2)
        {
            perso = new Mage();
            perso.promptCharacterInfo();
        }

        if (perso != null)
        {
            perso.showOptions();
        }


    }
}
