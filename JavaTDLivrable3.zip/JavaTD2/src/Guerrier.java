public class Guerrier extends Personnage {
    public Guerrier()
    {
    }


    @Override
    public int getMinHP() {
        return 10;
    }

    @Override
    public int getMaxHP() {
        return 15;
    }

    @Override
    public int getMinAttack() {
        return 10;
    }

    @Override
    public int getMaxAttack() {
        return 15;
    }

    @Override
    public String getWeaponPrompt() {
        return "Entrez une arme: ";
    }

    @Override
    public String getDefensePrompt() {
        return "Entrez un bouclier: ";
    }
}
