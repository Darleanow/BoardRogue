public class Mage extends Personnage{
    @Override
    public int getMinHP() {
        return 8;
    }

    @Override
    public int getMaxHP() {
        return 11;
    }

    @Override
    public int getMinAttack() {
        return 13;
    }

    @Override
    public int getMaxAttack() {
        return 20;
    }

    @Override
    public String getWeaponPrompt() {
        return "Entrez un sort: ";
    }

    @Override
    public String getDefensePrompt() {
        return "Entrez un philtre: ";
    }
}
