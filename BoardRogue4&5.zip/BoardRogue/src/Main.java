public class Main {
    public static void main(String[] args)
    {
        //Lancement du jeu et utilisation de la macro supress warnings (comme ça aucun warning :))
        @SuppressWarnings("unused")
        Game game = new Game();
    }
}